package com.pb8jv3.java1.webshopapp.filemanager.utility;

/**
 *
 * @author Kertesz Domonkos PB8JV3
 */
public class FailedFileCreationException extends Exception{

    public FailedFileCreationException(String string) {
	super(string);
    }
}
