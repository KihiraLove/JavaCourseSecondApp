package com.pb8jv3.java1.webshopapp.datamanager.data;

/**
 *
 * @author Kertesz Domonkos PB8JV3
 */
public class DisplaySize {
    Integer width;
    Integer height;

    public DisplaySize(Integer width, Integer height) {
	this.width = width;
	this.height = height;
    }

    public Integer getWidth() {
	return width;
    }

    public void setWidth(Integer width) {
	this.width = width;
    }

    public Integer getHeight() {
	return height;
    }

    public void setHeight(Integer height) {
	this.height = height;
    }    
}
